#!/usr/bin/env python3
# ==============================================================================
# MagCord V4 - License Bypassed | Dashboard & Bot 100% Working
# Credits: discord.gg/synthex | @siddhu.v2 | @siddhu_irl
# Dev really thought his little pyx crypto puzzle would hold up lmao. GG no re.
# ==============================================================================
from __future__ import annotations
import asyncio, json, os, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "core"))
os.chdir(ROOT)

# Drop lifetime grant in local db, fake auth forever
GRANT_PATH = ROOT / "database" / "license_grant.json"
GRANT_PATH.parent.mkdir(parents=True, exist_ok=True)
GRANT_PATH.write_text(json.dumps({
    "raw_grant": "MAG-XXXX-XXXX-XXXX",
    "issued_at": 0,
    "expires_at": 9_999_999_999,
    "valid": True,
}))
print("[bypass] license grant injected — lifetime access unlocked")

# Cut off outbound calls while importing api.so so it can't phone home
import socket as _bpsock

_bp_orig_connect  = _bpsock.socket.connect
_bp_orig_getaddr  = _bpsock.getaddrinfo
_BP_LOCAL = frozenset({'127.0.0.1', 'localhost', '::1', '0.0.0.0', ''})

# Every magcord-owned domain — blocked at raw socket level, forever, no exceptions
_BP_BLOCKED_HOSTS = (
    'magcord.io', 'magcord.com', 'magcord.bond',
    'mag-cord.io', 'mag-cord.com',
    'api.magcord', 'api2.magcord', 'api3.magcord',
    'license.magcord', 'auth.magcord', 'update.magcord',
)

def _bp_is_blocked(host: str) -> bool:
    h = str(host).lower().strip()
    return any(k in h for k in _BP_BLOCKED_HOSTS)

# Phase-1: full lockdown (only localhost allowed) — active during api.so import
def _bp_connect_lockdown(self, addr):
    h = addr[0] if isinstance(addr, (list, tuple)) else str(addr)
    if str(h).lower().strip() not in _BP_LOCAL:
        raise ConnectionRefusedError(111, '[bypass] blocked during import')
    return _bp_orig_connect(self, addr)

def _bp_getaddr_lockdown(host, port=None, *a, **kw):
    if str(host).lower().strip() not in _BP_LOCAL:
        raise OSError('[bypass] DNS blocked during import')
    return _bp_orig_getaddr(host, port, *a, **kw)

# Phase-2: runtime firewall — magcord servers hard-blocked, everything else allowed
def _bp_connect_runtime(self, addr):
    h = addr[0] if isinstance(addr, (list, tuple)) else str(addr)
    if _bp_is_blocked(h):
        raise ConnectionRefusedError(111, f'[bypass] magcord server blocked: {h}')
    return _bp_orig_connect(self, addr)

def _bp_getaddr_runtime(host, port=None, *a, **kw):
    if _bp_is_blocked(host):
        raise OSError(f'[bypass] magcord DNS blocked: {host}')
    return _bp_orig_getaddr(host, port, *a, **kw)

_bpsock.socket.connect = _bp_connect_lockdown
_bpsock.getaddrinfo    = _bp_getaddr_lockdown
print("[hook] ✓ socket blocker installed (phase-1 full lockdown during api.so import)")

# ── 3. Install dependencies (same as launch.py) ───────────────────────────────
from installer import ensure_dependencies
ensure_dependencies()

# ── 4. Define bypass handlers (must exist before we patch aiohttp) ────────────
import aiohttp.web as _aw
from aiohttp.web import json_response

async def _bypassed_handle_auth_verify(request: _aw.Request) -> _aw.Response:
    """Accept any license key unconditionally."""
    try:
        body = await request.json()
    except Exception:
        body = {}
    key = body.get("license_key", "BYPASSED")

    # Keep config.json in sync
    cfg_path = ROOT / "config" / "config.json"
    try:
        cfg = json.loads(cfg_path.read_text())
        cfg["license_key"] = key
        cfg_path.write_text(json.dumps(cfg, indent=4))
    except Exception:
        pass

    # Update grant file with the submitted key
    GRANT_PATH.write_text(json.dumps({
        "raw_grant": key,
        "issued_at": 0,
        "expires_at": 9_999_999_999,
        "valid": True,
    }))

    resp = json_response({
        "status": "success",
        "message": "License verified successfully.",
        "authenticated": True,
        "valid": True,
        "expires_at": 9_999_999_999,
    })
    # Set session cookie so /api/auth/check considers us logged in
    resp.set_cookie("mc_auth", "1", max_age=99_999_999, httponly=True, samesite="Strict")
    return resp


async def _bypassed_handle_auth_check(request: _aw.Request) -> _aw.Response:
    """Always report authenticated=True, required=False."""
    return json_response({
        "status": "authenticated",
        "authenticated": True,
        "required": False,
    })


def _bypass_is_request_authenticated(request=None) -> bool:
    """Sync version — Cython code calls this without await."""
    return True


# ── 4. Inject bypass middleware into EVERY aiohttp Application ───────────────
# We patch Application.__init__ so our middleware is ALWAYS prepended,
# even before api.so creates its app. This is the most reliable intercept.
_orig_app_init = _aw.Application.__init__

def _patched_app_init(self, *args, middlewares=(), **kwargs):
    bypass_mw = (_bypass_auth_middleware,)
    _orig_app_init(self, *args, middlewares=bypass_mw + tuple(middlewares), **kwargs)


@_aw.middleware
async def _bypass_auth_middleware(request: _aw.Request, handler):
    """Intercept auth endpoints before Cython handlers run."""
    path   = request.path
    method = request.method

    if method == "POST" and path in ("/api/auth/verify", "/api/auth/login"):
        print(f"[hook] ⚡ intercepted POST {path}")
        return await _bypassed_handle_auth_verify(request)

    if method == "GET" and path == "/api/auth/check":
        print(f"[hook] ⚡ intercepted GET {path}")
        return await _bypassed_handle_auth_check(request)

    return await handler(request)

_aw.Application.__init__ = _patched_app_init
print("[hook] ✓ aiohttp.Application.__init__ patched — bypass middleware will be injected")


# ── 5. Belt-and-suspenders: also intercept all add_* route registration ────────
# In case api.so references handlers by closure and not by module attribute,
# we swap them out at route-registration time too.

_ROUTE_BYPASSES = {
    "handle_auth_verify":  _bypassed_handle_auth_verify,
    "handle_auth_check":   _bypassed_handle_auth_check,
}

def _make_route_patcher(original_method):
    def _patched(self, method_or_path, path_or_handler=None, handler=None, **kwargs):
        # Normalise positional args for both add_route(method, path, handler)
        # and add_get/add_post(path, handler) signatures
        if handler is None and path_or_handler is not None and callable(path_or_handler):
            # add_get(path, handler) style
            actual_handler = path_or_handler
            actual_path    = method_or_path
            fn_name = getattr(actual_handler, "__name__", "") or \
                      getattr(actual_handler, "__qualname__", "")
            for key, repl in _ROUTE_BYPASSES.items():
                if key in fn_name:
                    print(f"[hook] ✓ route-registration swap for '{fn_name}'")
                    path_or_handler = repl
                    break
            return original_method(self, actual_path, path_or_handler, **kwargs)
        elif handler is not None:
            # add_route(method, path, handler) style
            fn_name = getattr(handler, "__name__", "") or \
                      getattr(handler, "__qualname__", "")
            for key, repl in _ROUTE_BYPASSES.items():
                if key in fn_name:
                    print(f"[hook] ✓ route-registration swap for '{fn_name}'")
                    handler = repl
                    break
            return original_method(self, method_or_path, path_or_handler, handler, **kwargs)
        else:
            return original_method(self, method_or_path, path_or_handler, **kwargs)
    return _patched

for _rmethod in ("add_route", "add_get", "add_post", "add_put", "add_delete", "add_patch", "add_head"):
    _orig = getattr(_aw.UrlDispatcher, _rmethod, None)
    if _orig:
        setattr(_aw.UrlDispatcher, _rmethod, _make_route_patcher(_orig))

print("[hook] ✓ UrlDispatcher route-registration methods patched")


# ── 6. Write bot wrapper script + intercept subprocess spawn ─────────────────
# api.so spawns:  python3.12 -u -c "import sys,...; from core import main; ..."
# main.so's __pyx_pymod_exec_main calls sys.exit() when the license check fails,
# which kills the subprocess BEFORE our postamble can patch anything.
#
# Hijack the bot command so our wrapper runs instead of dev's exit-trapped script
_WRAPPER_PATH = '/tmp/magcord_bot_bypass.py'

_BOT_WRAPPER = """#!/usr/bin/env python3
# MagCord V4 Bot Bypass | discord.gg/synthex | @siddhu.v2 | @siddhu_irl
import socket as _S, sys, builtins, os, asyncio, json
from pathlib import Path

# Lock down outbound during import, then open up all regular traffic
_OC = _S.socket.connect
_OG = _S.getaddrinfo
_LOCAL = frozenset({'127.0.0.1','localhost','::1','0.0.0.0',''})
_BLOCK_KEYWORDS = ('magcord.io', 'magcord.com', 'mag-cord.io', 'mag-cord.com', 'magcord.bond', 'api3.magcord')
_IMPORTING_MAIN = True

def _bg(host, port=None, *a, **kw):
    h = str(host).lower()
    if _IMPORTING_MAIN:
        if h not in _LOCAL:
            raise OSError('[bypass] socket blocked during import: ' + host)
    else:
        if any(k in h for k in _BLOCK_KEYWORDS):
            raise OSError('[bypass] license host blocked: ' + host)
    return _OG(host, port, *a, **kw)

def _bc(self, addr):
    h = addr[0] if isinstance(addr,(list,tuple)) else str(addr)
    h_str = str(h).lower()
    if _IMPORTING_MAIN:
        if h_str not in _LOCAL:
            raise ConnectionRefusedError(111, '[bypass] socket blocked during import')
    else:
        if any(k in h_str for k in _BLOCK_KEYWORDS):
            raise ConnectionRefusedError(111, '[bypass] license host blocked')
    return _OC(self, addr)

_S.socket.connect = _bc
_S.getaddrinfo    = _bg

# 2. Suppress sys.exit so license failure does not kill us
class _Sup(BaseException): pass
_OE = sys.exit
def _fe(code=0):
    if code != 0: raise _Sup(code)
    _OE(0)
sys.exit = _fe

# 3. Suppress license-error print banners
_OP = builtins.print
_BAD = ('CRITICAL ERROR','Invalid License','EXITING','Invalid Key','LICENSE ERROR')
def _fp(*a, **kw):
    t = ' '.join(str(x) for x in a)
    if any(b in t for b in _BAD): return
    _OP(*a, **kw)
builtins.print = _fp

# 4. Write license grant
Path('database/license_grant.json').write_text(
    json.dumps({'raw_grant':'BYPASSED','issued_at':0,'expires_at':9999999999,'valid':True}))

# 5. Import main (exit is suppressed so it cannot kill us)
sys.path.insert(0, os.path.abspath('core'))
sys.path.insert(0, os.path.abspath('.'))
main = None
try:
    from core import main
    _OP('[bypass] main.so imported OK')
except _Sup as _e:
    _OP(f'[bypass] main.so tried to exit({_e}), suppressed')
    main = sys.modules.get('main') or sys.modules.get('core.main')
except Exception as _e:
    _OP(f'[bypass] main.so import error: {_e}')
    main = sys.modules.get('main') or sys.modules.get('core.main')

# 6. Switch to runtime mode: all external APIs/connections allowed, ONLY license hosts blocked
_IMPORTING_MAIN = False
sys.exit       = _OE
builtins.print = _OP

# 7. Patch license functions / grant objects on main module
if main is not None:
    # _TC: an object that behaves exactly like True but is ALSO callable.
    # Fixes: on_ready does grant.valid() → True() → TypeError: 'bool' not callable
    class _TC:
        def __bool__(self): return True
        def __int__(self): return 1
        def __str__(self): return 'True'
        def __repr__(self): return 'True'
        def __eq__(self, o): return o is True or o == 1 or o == 'True'
        def __ne__(self, o): return not self.__eq__(o)
        def __hash__(self): return hash(True)
        def __call__(self, *a, **kw): return self   # True() → self (truthy)
        def __getattr__(self, _): return self        # True.anything → self (truthy callable)
    _TCI = _TC()

    class _G:
        # All boolean attrs are _TCI (truthy + callable) not raw True
        valid=_TCI;authenticated=_TCI;expires_at=9999999999;issued_at=0
        raw_grant='BYPASSED';license_key='BYPASSED';status='success'
        message='License verified.';user_id=None;hwid=None
        plan='lifetime';days_left=99999
        def __bool__(self): return True
        def __str__(self): return 'BYPASSED'
        def __repr__(self): return 'BypassGrant(valid=True)'
        def __getattr__(self, _): return _TCI       # any unknown attr → truthy callable
        def __call__(self, *a, **kw): return self
        def __await__(self):
            async def _r(): return self
            return _r().__await__()
    _GI = _G()
    # Make _bpt/_bpf also behave like _GI when attribute-accessed
    # (in case on_ready stores the function ref itself and reads .valid etc on it)
    class _Fn:
        # Callable that ALSO exposes all _G attrs, so .valid etc work on the fn object.
        valid=_TCI;authenticated=_TCI;expires_at=9999999999;issued_at=0
        raw_grant='BYPASSED';license_key='BYPASSED';status='success'
        message='License verified.';user_id=None;hwid=None
        plan='lifetime';days_left=99999
        def __init__(self, is_async=False):
            self._async = is_async
        def __bool__(self): return True
        def __getattr__(self, _): return _TCI       # any unknown attr → truthy callable
        def __call__(self, *a, **kw):
            if self._async:
                async def _r(): return _GI
                return _r()
            return _GI
        def __await__(self):
            async def _r(): return _GI
            return _r().__await__()
    _bpt = _Fn(is_async=True)
    _bpf = _Fn(is_async=False)
    def _bps(*a, **kw): return 'BYPASSED'
    for _n,_f in [('license_check',_bpt),('verify',_bpt),('validate_license',_bpt),
                   ('_verify_grant',_bpf),('_read_license_key',_bps),
                   ('check_license',_bpt),('get_grant',_bpf),('fetch_grant',_bpt)]:
        if hasattr(main,_n): setattr(main,_n,_f)
    for _an in ('grant','license_grant','current_grant','_grant','LICENSE'):
        if hasattr(main,_an): setattr(main,_an,_GI)

    # 8. Intercept discord.py event dispatch to suppress on_ready AttributeError.
    #    main.so's on_ready gets True from binary-patched validate_license (C path)
    #    then tries True.valid → AttributeError: 'bool' object has no attribute 'valid'
    #    OR it reads main.validate_license as a function ref → 'function' has no .valid
    try:
        import discord.client as _dc
        _orig_dispatch = _dc.Client.dispatch
        def _safe_dispatch(self, event, *args, **kwargs):
            try:
                return _orig_dispatch(self, event, *args, **kwargs)
            except (AttributeError, TypeError) as _ae:
                _OP(f'[bypass] suppressed dispatch {type(_ae).__name__} in on_{event}: {_ae}')
                return
            except Exception as _xe:
                if 'function' in str(_xe) or 'bool' in str(_xe) or 'NoneType' in str(_xe) or 'callable' in str(_xe):
                    _OP(f'[bypass] suppressed dispatch error in on_{event}: {_xe}')
                    return
                raise
        _dc.Client.dispatch = _safe_dispatch
        _OP('[bypass] patched discord.Client.dispatch (on_ready error suppression)')
    except Exception as _pe:
        _OP(f'[bypass] dispatch patch skipped: {_pe}')

    # 9. Patch Bot.on_error to suppress license AttributeErrors
    try:
        import discord.ext.commands as _commands
        _orig_on_err = _commands.Bot.on_error
        async def _safe_on_error(self, event_method, *args, **kwargs):
            import sys as _sys
            exc = _sys.exc_info()[1]
            if exc and isinstance(exc, (AttributeError, TypeError)):
                msg = str(exc)
                if any(k in msg for k in ('function', 'bool', 'NoneType', 'validate', 'grant', 'license')):
                    _OP(f'[bypass] suppressed on_error for {event_method}: {exc}')
                    return
            return await _orig_on_err(self, event_method, *args, **kwargs)
        _commands.Bot.on_error = _safe_on_error
        _OP('[bypass] patched Bot.on_error (AttributeError suppression)')
    except Exception as _pe:
        _OP(f'[bypass] on_error patch skipped: {_pe}')

    # 10. ALSO patch discord state's call_handlers to catch AttributeError/TypeError per-listener
    try:
        import discord.state as _ds
        if hasattr(_ds, 'ConnectionState'):
            _orig_ch = _ds.ConnectionState.call_handlers
            def _safe_ch(self, key, *args, **kwargs):
                try:
                    return _orig_ch(self, key, *args, **kwargs)
                except (AttributeError, TypeError) as _ae:
                    _OP(f'[bypass] suppressed call_handlers {type(_ae).__name__} for {key}: {_ae}')
                    return []
            _ds.ConnectionState.call_handlers = _safe_ch
            _OP('[bypass] patched ConnectionState.call_handlers')
    except Exception as _pe:
        _OP(f'[bypass] call_handlers patch skipped: {_pe}')

    print('[bypass] patches applied — starting bot')
    print('[bypass] 👑 MagCord V4 cracked by @siddhu.v2 & @siddhu_irl | discord.gg/synthex')
    asyncio.run(main.main()) if hasattr(main,'main') else None
else:
    print('[bypass] FATAL: main module unavailable')
    sys.exit(1)
"""

# Write the wrapper script
with open(_WRAPPER_PATH, 'w') as _wf:
    _wf.write(_BOT_WRAPPER)
print(f"[hook] Bot wrapper script written to {_WRAPPER_PATH}")

# Patch asyncio.create_subprocess_exec — replace -c with wrapper path
import asyncio as _asyncio
_orig_cse = _asyncio.create_subprocess_exec

async def _patched_cse(program, *args, **kwargs):
    new_args = list(args)
    for i, arg in enumerate(new_args):
        if isinstance(arg, str) and 'from core import main' in arg:
            # args look like: ['-u', '-c', '<script>']
            # find -c and replace with wrapper path, remove script string
            for j in range(len(new_args)):
                if new_args[j] == '-c':
                    new_args[j] = _WRAPPER_PATH  # replace -c with script path
                    new_args.pop(i)               # remove script string
                    break
            print('[hook] replaced bot -c with wrapper script', flush=True)
            break
    return await _orig_cse(program, *new_args, **kwargs)

_asyncio.create_subprocess_exec = _patched_cse

# Patch subprocess.Popen as fallback
import subprocess as _subprocess
_orig_pi = _subprocess.Popen.__init__

def _patched_pi(self, args, **kwargs):
    if isinstance(args, (list, tuple)):
        new_args = list(args)
        for i, a in enumerate(new_args):
            if isinstance(a, str) and 'from core import main' in a:
                for j in range(len(new_args)):
                    if new_args[j] == '-c':
                        new_args[j] = _WRAPPER_PATH
                        new_args.pop(i)
                        break
                print('[hook] replaced bot -c with wrapper script', flush=True)
                break
        args = new_args
    _orig_pi(self, args, **kwargs)

_subprocess.Popen.__init__ = _patched_pi
print("[hook] subprocess interceptor installed (wrapper script mode)")


# ── 7. Import api module (after all patches so it sees our aiohttp) ───────────
# api.so init-time network call will fail fast thanks to socket blocker above.
print("[hook] Importing api.so (license init call will be blocked)...")
import api as _api_mod
print("[hook] ✓ api.so imported successfully")

# ── Switch to phase-2: runtime firewall ──────────────────────────────────────
# Full lockdown is lifted now that api.so is imported.
# Replace with permanent runtime firewall: magcord servers still hard-blocked,
# discord.com and everything else goes through normally.
_bpsock.socket.connect = _bp_connect_runtime
_bpsock.getaddrinfo    = _bp_getaddr_runtime
print("[hook] ✓ socket switched to phase-2 — magcord servers permanently firewalled")

# ── 7b. Intercept aiohttp ClientSession to block license renewal calls ────────
# The _on_startup_license_monitor loop uses aiohttp ClientSession.get/post to
# periodically re-validate the license. We intercept it at the aiohttp layer:
# any request whose URL path contains license-check keywords returns a fake
# "valid" JSON response without hitting the real server.
import aiohttp as _aiohttp
import contextlib as _contextlib

_ORIG_CS_INIT = _aiohttp.ClientSession.__init__

class _FakeResp:
    """Minimal async context manager that returns a fake valid license response."""
    status = 200
    async def json(self, **kw):
        return {"valid": True, "status": "success", "message": "License verified.",
                "expires_at": 9999999999, "issued_at": 0, "plan": "lifetime",
                "raw_grant": "MAG-XXXX-XXXX-XXXX"}
    async def text(self, **kw):
        import json as _j
        return _j.dumps(await self.json())
    async def read(self): return b'{"valid":true}'
    async def __aenter__(self): return self
    async def __aexit__(self, *a): pass
    def raise_for_status(self): pass

class _FakeUpdateResp:
    """Fake response for updater.so manifest/file fetches — tells it nothing to update."""
    status = 404
    async def json(self, **kw):
        return {}
    async def text(self, **kw):
        return "{}"
    async def read(self): return b'{}'
    async def __aenter__(self): return self
    async def __aexit__(self, *a): pass
    def raise_for_status(self): pass

def _pick_fake_resp(url):
    u = str(url).lower()
    # updater hits manifest.json and /files/ — give it 404 so it skips the update
    if 'magcord.bond' in u or 'api3.magcord' in u or 'manifest.json' in u:
        return _FakeUpdateResp()
    return _FakeResp()

_LICENSE_URL_KEYWORDS = ('license', 'grant', 'verify', 'validate', 'auth/key',
                         'magcord', 'mag-api', 'api/v1/license', 'magcord.bond',
                         'api3.magcord', 'manifest.json')

def _is_license_url(url):
    u = str(url).lower()
    # block anything hitting magcord servers OR license endpoints, but never discord
    return any(k in u for k in _LICENSE_URL_KEYWORDS) and 'discord.com' not in u

def _make_session_method(orig_method_name):
    import functools
    def _patched_method(self, url, *a, **kw):
        if _is_license_url(url):
            print(f"[hook] ⚡ intercepted license HTTP call: {url}")
            return _FakeResp()
        orig = object.__getattribute__(self, '_orig_' + orig_method_name)
        return orig(url, *a, **kw)
    return _patched_method

_ORIG_SESSION_GET  = _aiohttp.ClientSession.get
_ORIG_SESSION_POST = _aiohttp.ClientSession.post

def _patched_cs_init(self, *a, **kw):
    _ORIG_CS_INIT(self, *a, **kw)
    object.__setattr__(self, '_orig_get',  _ORIG_SESSION_GET.__get__(self))
    object.__setattr__(self, '_orig_post', _ORIG_SESSION_POST.__get__(self))

# Simpler approach: patch at class level
_orig_cs_get  = _aiohttp.ClientSession.get
_orig_cs_post = _aiohttp.ClientSession.post

def _patched_cs_get(self, url, *a, **kw):
    if _is_license_url(url):
        print(f"[hook] ⚡ intercepted license GET: {url}")
        return _pick_fake_resp(url)
    return _orig_cs_get(self, url, *a, **kw)

def _patched_cs_post(self, url, *a, **kw):
    if _is_license_url(url):
        print(f"[hook] ⚡ intercepted license POST: {url}")
        return _pick_fake_resp(url)
    return _orig_cs_post(self, url, *a, **kw)

_aiohttp.ClientSession.get  = _patched_cs_get
_aiohttp.ClientSession.post = _patched_cs_post
print("[hook] ✓ aiohttp.ClientSession patched — license renewal calls will be intercepted")

# ── 8. Best-effort module-attribute patches (extra safety) ───────────────────
for _name, _fn in [
    ("handle_auth_verify",        _bypassed_handle_auth_verify),
    ("handle_auth_check",         _bypassed_handle_auth_check),
    ("is_request_authenticated",  _bypass_is_request_authenticated),
]:
    if hasattr(_api_mod, _name):
        setattr(_api_mod, _name, _fn)
        print(f"[hook] ✓ patched api.{_name}")
    else:
        print(f"[hook] ℹ  api.{_name} not found as module attr")

# ── 9. Patch _grant_state dict and all license validation functions ───────────
# run_server() reads _grant_state['grant'] to check if the license is valid.
# After import with socket blocker, _grant_state = {grant: None, exp: 0, lock: None}
# We must set it to a valid state before run_server() is called.
import time as _time

_FAKE_GRANT = {
    "raw_grant":   "MAG-XXXX-XXXX-XXXX",
    "valid":       True,
    "authenticated": True,
    "issued_at":   0,
    "expires_at":  9_999_999_999,
    "plan":        "lifetime",
    "days_left":   99999,
    "status":      "success",
    "message":     "License verified.",
}

# Populate the _grant_state dict (it's a module-level mutable dict)
try:
    gs = _api_mod._grant_state
    gs["grant"] = _FAKE_GRANT
    gs["exp"]   = _time.time() + 86400 * 3650  # expires in 10 years
    if gs.get("lock") is None:
        import asyncio as _al
        try:
            gs["lock"] = _al.Lock()
        except Exception:
            pass
    print(f"[hook] ✓ _grant_state populated: grant=FAKE_GRANT exp={gs['exp']:.0f}")
except Exception as _e:
    print(f"[hook] ⚠ could not set _grant_state: {_e}")

# Patch all license-check Python-callable functions to return a truthy value
# validate_license may be called with or without await from Cython code,
# so we use a class that works both ways.
class _GrantResult(dict):
    """A dict subclass that is also awaitable, so it works in both sync and async contexts."""
    def __bool__(self): return True
    def __await__(self):
        async def _r(): return self
        return _r().__await__()
    def __call__(self, *a, **kw): return self

_GR = _GrantResult(_FAKE_GRANT)

def _bypass_validate_license(*a, **kw):
    return _GR

def _bypass_validate_license_async(*a, **kw):
    return _GR

def _bypass_load_disk_license_grant(*a, **kw):
    return _GR

def _bypass_save_license_grant(*a, **kw):
    return True

for _name, _fn in [
    ("validate_license",        _bypass_validate_license),
    ("validate_license_async",  _bypass_validate_license_async),
    ("load_disk_license_grant", _bypass_load_disk_license_grant),
    ("save_license_grant",      _bypass_save_license_grant),
]:
    if hasattr(_api_mod, _name):
        setattr(_api_mod, _name, _fn)
        print(f"[hook] ✓ patched api.{_name}")
    else:
        print(f"[hook] ℹ  api.{_name} not found")

# Also suppress print_critical_error so any remaining checks are silent
def _bypass_print_critical_error(*a, **kw):
    print(f"[hook] ⚡ suppressed print_critical_error: {a}")

if hasattr(_api_mod, "print_critical_error"):
    _api_mod.print_critical_error = _bypass_print_critical_error
    print("[hook] ✓ patched api.print_critical_error → suppressed")

# Noop out auth_middleware (the bypass middleware above is now primary)
try:
    if hasattr(_api_mod, "auth_middleware"):
        @_aw.middleware
        async def _noop_auth_middleware(request, handler):
            return await handler(request)
        _api_mod.auth_middleware = _noop_auth_middleware
        print("[hook] ✓ patched api.auth_middleware → noop")
except Exception as _e:
    print(f"[hook] ⚠ auth_middleware patch skipped: {_e}")

# ── 10. Auto-start Bot Worker ─────────────────────────────────────────────────
# As soon as the dashboard web server binds its configured port and is alive,
# trigger /api/bot/start so both dashboard and bot run simultaneously.
def _auto_start_bot_worker():
    import http.client, time as _t, json
    
    # Read port dynamically from config/config.json if user customized it
    target_port = 2001
    try:
        cfg_file = ROOT / "config" / "config.json"
        if cfg_file.exists():
            cfg_data = json.loads(cfg_file.read_text(encoding="utf-8"))
            target_port = int(cfg_data.get("port", 2001))
    except Exception:
        target_port = 2001

    _t.sleep(1.5)
    for _ in range(40):
        try:
            conn = http.client.HTTPConnection("127.0.0.1", target_port, timeout=2)
            conn.request("GET", "/api/auth/check")
            res = conn.getresponse()
            conn.close()
            if res.status in (200, 302, 401, 403, 404):
                break
        except Exception:
            pass
        _t.sleep(0.5)
    else:
        print(f"[auto-start] ⚠ dashboard server did not respond on port {target_port} within 20s", flush=True)
        return

    _t.sleep(1.0)
    for _ in range(5):
        try:
            conn = http.client.HTTPConnection("127.0.0.1", target_port, timeout=5)
            headers = {
                "Cookie": "mc_auth=1",
                "Content-Type": "application/json"
            }
            conn.request("POST", "/api/bot/start", body="{}", headers=headers)
            res = conn.getresponse()
            body = res.read().decode("utf-8", errors="ignore")
            conn.close()
            print("[bypass] ✓ Bot auto-kickstarted through dashboard.", flush=True)
            print("[bypass] ⏳ Sit back, bot takes ~25-30s to sync friends & server cache...", flush=True)
            print("[bypass] 👑 Cracked by: @siddhu.v2 & @siddhu_irl | discord.gg/synthex", flush=True)
            return
        except Exception:
            _t.sleep(1.0)

import threading as _threading
_threading.Thread(target=_auto_start_bot_worker, daemon=True).start()

import warnings as _warnings
_warnings.filterwarnings("ignore", category=RuntimeWarning, message="coroutine '.*' was never awaited")
print("[bypass] DRM trashed. Starting dashboard server... | discord.gg/synthex | @siddhu.v2 | @siddhu_irl\n")

def main():
    print("\033[2J\033[H", end="", flush=True)
    os.system("clear")
    try:
        _api_mod.run_server()
    except KeyboardInterrupt:
        print("\n[INFO] Dashboard server stopped by user.")
    except Exception as e:
        print(f"[ERROR] {e}")
        import traceback; traceback.print_exc()

if __name__ == "__main__":
    main()

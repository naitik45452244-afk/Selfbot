#!/usr/bin/env python3
# MagCord V4 - Cracked & fully bypassed. Both dashboard + selfbot working 100%.
# Credits: discord.gg/synthex | @siddhu.v2 | @siddhu_irl
# Imagine paying for a sh!t selfbot in 2026 lmao. Enjoy the free ride.

import os, sys, subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent

print("==================================================================")
print("  MagCord V4 Cracked | Discord Selfbot & Dashboard 100% Working   ")
print("  Credits: @siddhu.v2 & @siddhu_irl | discord.gg/synthex           ")
print("==================================================================\n")

if sys.platform == "win32":
    drive = str(ROOT.drive).rstrip(":").lower()
    rel = str(ROOT)[len(ROOT.drive)+1:].replace("\\", "/")
    wsl_root = f"/mnt/{drive}/{rel}"
    cmd = [
        "wsl.exe", "-d", "ubuntu", "--", "bash", "-ic",
        f"cd '{wsl_root}' && source venv/bin/activate && python3.12 run.py"
    ]
    try:
        sys.exit(subprocess.call(cmd))
    except KeyboardInterrupt:
        sys.exit(0)
else:
    venv_py = ROOT / "venv" / "bin" / "python3"
    target_script = str(ROOT / "hook_launch.py")

    py_bin = str(venv_py) if venv_py.exists() else sys.executable
    os.chdir(ROOT)
    os.execv(py_bin, [py_bin, target_script] + sys.argv[1:])

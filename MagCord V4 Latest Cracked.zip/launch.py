import sys
import os

_ROOT = os.path.dirname(os.path.abspath(__file__))
_CORE = os.path.join(_ROOT, "core")
for p in [_ROOT, _CORE]:
    if p not in sys.path:
        sys.path.insert(0, p)

from installer import ensure_dependencies
ensure_dependencies()

from core import api
 
if __name__ == "__main__":
    print("\033[2J\033[H", end="", flush=True)
    os.system('cls' if os.name == 'nt' else 'clear')
    try:
        api.run_server()
    except KeyboardInterrupt:
        print("\n[INFO] Dashboard server stopped by user.")
    except Exception as e:
        print(f"[ERROR] {e}")

@echo off
set "DIR=%~dp0"

wsl -d Ubuntu --cd "%DIR%" bash -c "source venv/bin/activate && python3.12 run.py"

pause
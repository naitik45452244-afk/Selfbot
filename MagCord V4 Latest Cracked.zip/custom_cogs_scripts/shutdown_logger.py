import sys
import os
import atexit
import signal
import asyncio
import traceback
from datetime import datetime
import discord
from discord.ext import commands, tasks

# Ensure utils can be imported
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_CORE = os.path.join(_ROOT, "core")
for p in [_ROOT, _CORE]:
    if p not in sys.path:
        sys.path.insert(0, p)

LOG_FILE_PATH = os.path.join(_ROOT, "bot_shutdown.log")
LOGS_DIR_PATH = os.path.join(_ROOT, "logs", "bot_shutdown.log")

def _write_log(message: str):
    """Safely appends a formatted entry to both root and logs directory shutdown logs."""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    pid = os.getpid()
    log_line = f"[{timestamp}] [PID {pid}] {message.strip()}\n"
    
    # 1. Write to root bot_shutdown.log
    for target_path in [LOG_FILE_PATH, LOGS_DIR_PATH]:
        try:
            os.makedirs(os.path.dirname(target_path), exist_ok=True)
            # Roll over if file exceeds 5MB
            if os.path.exists(target_path) and os.path.getsize(target_path) > 5 * 1024 * 1024:
                try:
                    backup_path = target_path + ".old"
                    if os.path.exists(backup_path):
                        os.remove(backup_path)
                    os.rename(target_path, backup_path)
                except Exception:
                    pass
            with open(target_path, "a", encoding="utf-8", errors="replace") as f:
                f.write(log_line)
                f.flush()
        except Exception:
            pass

# ---------------------------------------------------------------------------
# 1. Global sys.exit Interception
# ---------------------------------------------------------------------------
_original_sys_exit = sys.exit

def _logged_sys_exit(code=0):
    try:
        # Extract caller stack excluding our wrapper
        stack = "".join(traceback.format_stack()[:-1])
        _write_log(f"[SYS.EXIT CALL] sys.exit({code}) was invoked.\nCaller Stack:\n{stack}")
    except Exception:
        pass
    return _original_sys_exit(code)

sys.exit = _logged_sys_exit

# ---------------------------------------------------------------------------
# 2. OS Signals Interception (SIGINT, SIGTERM, SIGHUP)
# ---------------------------------------------------------------------------
_registered_signals = {}

def _signal_handler(sig, frame):
    try:
        signame = signal.Signals(sig).name if hasattr(signal, "Signals") else f"Signal {sig}"
        _write_log(f"[OS SIGNAL] Process received {signame} (Signal {sig}). Process is being terminated by host / system / user.")
    except Exception:
        pass
    
    original = _registered_signals.get(sig)
    if callable(original) and original not in (_signal_handler, signal.SIG_DFL, signal.SIG_IGN):
        try:
            return original(sig, frame)
        except Exception:
            pass
    _original_sys_exit(128 + sig)

for sig_name in ["SIGTERM", "SIGINT", "SIGHUP"]:
    if hasattr(signal, sig_name):
        sig_num = getattr(signal, sig_name)
        try:
            _registered_signals[sig_num] = signal.getsignal(sig_num)
            signal.signal(sig_num, _signal_handler)
        except Exception:
            pass

# ---------------------------------------------------------------------------
# 3. atexit Process Exit Hook
# ---------------------------------------------------------------------------
def _process_exit_hook():
    try:
        exc_type, exc_val, exc_tb = sys.exc_info()
        if exc_type is not None and exc_type is not SystemExit:
            err_text = "".join(traceback.format_exception(exc_type, exc_val, exc_tb))
            _write_log(f"[FATAL CRASH] Process exiting due to unhandled exception:\n{err_text}")
        else:
            _write_log(f"[PROCESS TERMINATED] Python selfbot process shutdown finished.")
    except Exception:
        pass

atexit.register(_process_exit_hook)


# ---------------------------------------------------------------------------
# 4. Shutdown Logger Cog
# ---------------------------------------------------------------------------
class ShutdownLogger(commands.Cog):
    """Custom Cog for monitoring, logging, and diagnosing bot shutdowns, crashes, and disconnects."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        _write_log(f"[PROCESS START] MagCord Selfbot Cog loaded successfully. System monitoring active.")
        self._setup_asyncio_exception_handler()
        if not self.health_monitor.is_running():
            self.health_monitor.start()

    def cog_unload(self):
        if self.health_monitor.is_running():
            self.health_monitor.stop()
        _write_log(f"[COG UNLOAD] ShutdownLogger cog was unloaded.")

    def _setup_asyncio_exception_handler(self):
        try:
            loop = self.bot.loop if hasattr(self.bot, "loop") and self.bot.loop else asyncio.get_event_loop()
            prev_handler = loop.get_exception_handler()

            def custom_handler(target_loop, context):
                try:
                    msg = context.get("message", "Unhandled Asyncio Exception")
                    exc = context.get("exception")
                    if exc:
                        tb = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
                        _write_log(f"[ASYNCIO ERROR] {msg}:\n{tb}")
                    else:
                        _write_log(f"[ASYNCIO ERROR] {msg} (Context: {context})")
                except Exception:
                    pass
                if prev_handler:
                    try:
                        prev_handler(target_loop, context)
                    except Exception:
                        pass
                else:
                    try:
                        target_loop.default_exception_handler(context)
                    except Exception:
                        pass

            loop.set_exception_handler(custom_handler)
        except Exception as e:
            _write_log(f"[WARNING] Failed to attach asyncio exception handler: {e}")

    # --- Gateway Connection Listeners ---

    @commands.Cog.listener()
    async def on_disconnect(self):
        _write_log("[DISCORD DISCONNECT] Gateway connection closed. Bot is temporarily disconnected from Discord gateway.")

    @commands.Cog.listener()
    async def on_connect(self):
        _write_log("[DISCORD CONNECT] Gateway connected successfully.")

    @commands.Cog.listener()
    async def on_resumed(self):
        _write_log("[DISCORD RESUMED] Gateway session resumed successfully.")

    @commands.Cog.listener()
    async def on_error(self, event, *args, **kwargs):
        try:
            err = traceback.format_exc()
            _write_log(f"[EVENT ERROR] Error occurred in event '{event}':\n{err}")
        except Exception:
            pass

    # --- Periodic Health & Resource Monitor ---

    @tasks.loop(seconds=60)
    async def health_monitor(self):
        """Monitors system memory and license state to catch OOM or license expiries before fatal crash."""
        try:
            import psutil
            proc = psutil.Process(os.getpid())
            mem_info = proc.memory_info()
            rss_mb = mem_info.rss / (1024 * 1024)
            
            # If RAM usage exceeds 450MB, log an early warning for Pterodactyl container users
            if rss_mb > 450:
                _write_log(f"[RAM WARNING] High Memory Usage detected: {rss_mb:.1f} MB RSS. Potential risk of container OOM kill (SIGKILL 137).")
        except Exception:
            pass

        try:
            # Check grant expiry in main.py globals if present
            main_mod = sys.modules.get("core.main") or sys.modules.get("main")
            if main_mod and hasattr(main_mod, "_grant_state"):
                grant = getattr(main_mod, "_grant_state", {})
                exp = grant.get("exp", 0)
                if exp > 0:
                    remaining = exp - int(datetime.now().timestamp())
                    if 0 < remaining < 60:
                        _write_log(f"[LICENSE WARNING] License grant expires in {remaining}s. Renewal might be lagging.")
        except Exception:
            pass


async def setup(bot: commands.Bot):
    await bot.add_cog(ShutdownLogger(bot))

